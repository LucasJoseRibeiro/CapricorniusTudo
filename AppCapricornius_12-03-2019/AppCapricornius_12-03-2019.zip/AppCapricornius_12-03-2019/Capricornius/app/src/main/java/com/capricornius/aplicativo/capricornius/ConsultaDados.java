package com.capricornius.aplicativo.capricornius;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ConsultaDados extends AppCompatActivity {

    String idUsuario;
    ListView listView = null;
    public BancoDados bd;
    int numTabela = 0;
    private static final String[] FICHAS = new String[] { "PesagemAnimal", "EscoreCorporal", "PartoNascimento", "Desmama", "OcorrenciaDiversa",
                                                            "SaidaAnimal", "PesagemLeite"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_dados);

        bd = new BancoDados(this);
        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");

        ActionBarUtil.configureActionBar(this, (float) 1.0);

        //cria um ArrayAdapter para exibir os estados
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, FICHAS);
        AutoCompleteTextView fichas = findViewById(R.id.CDBusca);
        fichas.setAdapter(adaptador);
    }


    public void BuscarDados(View view) {
        try {
            final AutoCompleteTextView nomeTabela = findViewById(R.id.CDBusca);
            String where = "idUsuario = '" + idUsuario + "'";
            String coluna1 = null, coluna2 = null, coluna3 = null, coluna4 = null, coluna5 = null, coluna6 = null;
            int quantCamposConsulta = 0;

            //cada ficha tem uma certa quantidade de colunas, entao quando o usuario seleciona uma determinada ficha
            //é setado as strings da coluna que serao usadas na consulta no BD, respectivamente o numero da tabela
            Cursor cursorConsulta = null;
            //compara o nome que o usuario digitou com o nome da tabela
            if(nomeTabela.getText().toString().equals("SaidaAnimal")){
                coluna1 = "SARegistroAnimal";
                coluna2 = "SAData";
                coluna3 = "SAMotivo";
                coluna4 = "SACausa";
                coluna5 = "SAOcorrencia";
                quantCamposConsulta = 5;
                numTabela = 1;
            }
            else if(nomeTabela.getText().toString().equals("PesagemAnimal")){
                coluna1 = "PARegistroAnimal";
                coluna2 = "PADataPesagem";
                coluna3 = "PAPeso";
                quantCamposConsulta = 3;
                numTabela = 2;
            }
            else if(nomeTabela.getText().toString().equals("OcorrenciaDiversa")){
                coluna1 = "ODRegistroAnimal";
                coluna2 = "ODData";
                coluna3 = "ODOcorrencia";
                quantCamposConsulta = 3;
                numTabela = 3;
            }
            else if(nomeTabela.getText().toString().equals("Desmama")){
                coluna1 = "DERegistroAnimal";
                coluna2 = "DEData";
                coluna3 = "DEPesoDesmama";
                quantCamposConsulta = 3;
                numTabela = 4;
            }
            else if(nomeTabela.getText().toString().equals("PesagemLeite")){
                coluna1 = "PLRegistroAnimal";
                coluna2 = "PLData";
                coluna3 = "PLProducao1";
                coluna4 = "PLProducao2";
                coluna5 = "PLProducao3";
                coluna6 = "PLOcorrencia";
                quantCamposConsulta = 6;
                numTabela = 5;
            }
            else if(nomeTabela.getText().toString().equals("EscoreCorporal")){
                coluna1 = "ECRegistroAnimal";
                coluna2 = "ECData";
                coluna3 = "ECAvaliacao1";
                coluna4 = "ECAvaliacao2";
                coluna5 = "ECAvaliacao3";
                quantCamposConsulta = 5;
                numTabela = 6;
            }
            else{
                Toast.makeText(this, "Consulta Inválida", Toast.LENGTH_SHORT).show();
            }
            // mostra cada coluna da tabela para o usuario, em forma de lista
            final List<String> listaDados = new ArrayList<String>(); //usada no adapter para mostrar os campos com os valores

            final List<String> listaAux = new ArrayList<String>(); // lista usada com os valores para serem passados para editar
                                                        //é possivel que o usuario edite qualquer dado de qualquer ficha

            //compara qual tabela foi selecionada pelo usuario, comparando o numero de campos
            //a variavel dados armazena o que será mostrado na tela para o usuario
            //a variavel aux armazena as colunas separadas por virgula, para serem tratadas posteriormente quando o usuario selecionar
            // a opção de editar dados (clicar em qualquer linha listView)
            if(quantCamposConsulta == 3) {
                cursorConsulta = bd.buscar(nomeTabela.getText().toString(), new String[]{coluna1, coluna2, coluna3}, where, coluna2);
                while (cursorConsulta.moveToNext()) {
                    int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                    int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                    int idColuna3 = cursorConsulta.getColumnIndex(coluna3);

                    String dados = coluna1.substring(2) + ": " + cursorConsulta.getInt(idColuna1) + "\n"+ coluna2.substring(2) +": "
                            + cursorConsulta.getString(idColuna2) + "\n" +coluna3.substring(2) +": " + cursorConsulta.getString(idColuna3);
                    String aux = cursorConsulta.getInt(idColuna1) + "," + cursorConsulta.getString(idColuna2) + ","
                            + cursorConsulta.getString(idColuna3);

                    listaAux.add(aux);
                    listaDados.add(dados);
                }
            }
            else if(quantCamposConsulta == 5) {
                cursorConsulta = bd.buscar(nomeTabela.getText().toString(), new String[]{coluna1, coluna2, coluna3, coluna4, coluna5}, where, coluna2);
                while (cursorConsulta.moveToNext()) {
                    int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                    int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                    int idColuna3 = cursorConsulta.getColumnIndex(coluna3);
                    int idColuna4 = cursorConsulta.getColumnIndex(coluna4);
                    int idColuna5 = cursorConsulta.getColumnIndex(coluna5);

                    String dados = coluna1.substring(2) + ": " + cursorConsulta.getInt(idColuna1) + "\n"+ coluna2.substring(2) +": "
                            + cursorConsulta.getString(idColuna2) + "\n" +coluna3.substring(2) +": " + cursorConsulta.getString(idColuna3) +
                            "\n" + coluna4.substring(2) + ": " + cursorConsulta.getString(idColuna4) + "\n" + coluna5.substring(2) + ": "
                            + cursorConsulta.getString(idColuna5);
                    String aux = cursorConsulta.getInt(idColuna1) + "," + cursorConsulta.getString(idColuna2) + ","
                            + cursorConsulta.getString(idColuna3) + "," + cursorConsulta.getString(idColuna4) + ","
                            + cursorConsulta.getString(idColuna5);

                    listaAux.add(aux);
                    listaDados.add(dados);
                }
            }
            else if(quantCamposConsulta == 6) {
                cursorConsulta = bd.buscar(nomeTabela.getText().toString(), new String[]{coluna1, coluna2, coluna3, coluna4, coluna5, coluna6}, where, coluna2);
                while (cursorConsulta.moveToNext()) {
                    int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                    int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                    int idColuna3 = cursorConsulta.getColumnIndex(coluna3);
                    int idColuna4 = cursorConsulta.getColumnIndex(coluna4);
                    int idColuna5 = cursorConsulta.getColumnIndex(coluna5);
                    int idColuna6 = cursorConsulta.getColumnIndex(coluna6);

                    String dados = coluna1.substring(2) + ": " + cursorConsulta.getInt(idColuna1) + "\n"+ coluna2.substring(2) +": "
                            + cursorConsulta.getString(idColuna2) + "\n" +coluna3.substring(2) +": " + cursorConsulta.getString(idColuna3) +
                            "\n" + coluna4.substring(2) + ": " + cursorConsulta.getString(idColuna4) + "\n" + coluna5.substring(2) + ": "
                            + cursorConsulta.getString(idColuna5) + "\n" + coluna6.substring(2) + ": " + cursorConsulta.getString(idColuna6);
                    String aux = cursorConsulta.getInt(idColuna1) + "," + cursorConsulta.getString(idColuna2) + ","
                            + cursorConsulta.getString(idColuna3) + "," + cursorConsulta.getString(idColuna4) + ","
                            + cursorConsulta.getString(idColuna5) + "," + cursorConsulta.getString(idColuna6);

                    listaAux.add(aux);
                    listaDados.add(dados);
                }
            }
            cursorConsulta.close();

            listView = findViewById(R.id.CDlistaConsulta);
            int layout = android.R.layout.simple_list_item_1;
            final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, layout, listaDados);
            listView.setAdapter(adapter);

            //trata o clique de cada linha da listView
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String [] valorColuna = new String[6];
                    int j = 0;
                    //guarda o conteudo de cada coluna
                    for (int i = 0; i < listaAux.get(position).length(); i++) {
                        if (listaAux.get(position).charAt(i) != ',') {
                            if(valorColuna[j] != null)
                                valorColuna[j] = valorColuna[j] + listaAux.get(position).charAt(i);
                            else{
                                valorColuna[j] = String.valueOf(listaAux.get(position).charAt(i));
                            }
                        } else {
                            j++;
                        }
                    }

                    if(numTabela == 1){
                        Intent intent = new Intent(getBaseContext(), FichaSaidaAnimais.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("motivo", valorColuna[2]);
                        intent.putExtra("causa", valorColuna[3]);
                        intent.putExtra("ocorrencia", valorColuna[4]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Saida Animal:" + idUsuario + " " + valorColuna[0] + " " +valorColuna[1] +
                                valorColuna[2] + " " + valorColuna[3] + " " + valorColuna[4], Toast.LENGTH_LONG).show();
                    }
                    else if (numTabela == 2){
                        Intent intent = new Intent(getBaseContext(), FichaPesagemAnimal.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("peso", valorColuna[2]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Pesagem Animal:" + idUsuario + " " + valorColuna[0] + " " +valorColuna[1] +
                                " " + valorColuna[2], Toast.LENGTH_LONG).show();
                    }
                    else if(numTabela == 3){
                        Intent intent = new Intent(getBaseContext(), FichaOcorrenciasDiversas.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("ocorrencia", valorColuna[2]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Ocorrencia Animal:"+ idUsuario + " " + valorColuna[0] + " " +valorColuna[1]+
                                " " + valorColuna[2], Toast.LENGTH_LONG).show();
                    }
                    else if(numTabela == 4){
                        Intent intent = new Intent(getBaseContext(), FichaDesmama.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("peso", valorColuna[2]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Desmama:" + valorColuna[0] + " " +valorColuna[1], Toast.LENGTH_LONG).show();
                    }
                    else if(numTabela == 5){
                        Intent intent = new Intent(getBaseContext(), FichaPesagemLeite.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("producao1", valorColuna[2]);
                        intent.putExtra("producao2", valorColuna[3]);
                        intent.putExtra("producao3", valorColuna[4]);
                        intent.putExtra("ocorrencia", valorColuna[5]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Pesagem Leite:" + idUsuario + " " + valorColuna[0] + " " +valorColuna[1] +
                                valorColuna[2] + " " + valorColuna[3] + " " + valorColuna[4], Toast.LENGTH_LONG).show();
                    }
                    else if(numTabela == 6){
                        Intent intent = new Intent(getBaseContext(), FichaEscoreCorporal.class);
                        intent.putExtra("idUsuario",idUsuario);
                        intent.putExtra("controle",1);
                        intent.putExtra("registro", valorColuna[0]);
                        intent.putExtra("data", valorColuna[1]);
                        intent.putExtra("avaliador1", valorColuna[2]);
                        intent.putExtra("avaliador2", valorColuna[3]);
                        intent.putExtra("avaliador3", valorColuna[4]);
                        startActivity(intent);
                        finish();

                        Toast.makeText(getBaseContext(), "Escore Corporal:" + idUsuario + " " + valorColuna[0] + " " +valorColuna[1] +
                                valorColuna[2] + " " + valorColuna[3] + " " + valorColuna[4], Toast.LENGTH_LONG).show();
                    }
                }
            });


        }catch (Exception e){
            Toast.makeText(this, "Falha na operação", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
