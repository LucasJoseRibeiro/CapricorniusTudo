package com.capricornius.aplicativo.capricornius;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaPartosNascimentos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_partos_nascimentos);

        ActionBarUtil.configureActionBar(this, (float) 1.0);
    }

    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date PNdataatual = new Date();

        EditText PNdata = findViewById(R.id.PNedtData);
        PNdata.setText(simpleDateFormat.format(PNdataatual).toString());
    }

    public void PNsalvarVoltar(View view) {
        Toast.makeText(this, "Essa funcionalidade ainda não foi feita", Toast.LENGTH_LONG).show();
    }

    public void PNsalvarContinuar(View view) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
