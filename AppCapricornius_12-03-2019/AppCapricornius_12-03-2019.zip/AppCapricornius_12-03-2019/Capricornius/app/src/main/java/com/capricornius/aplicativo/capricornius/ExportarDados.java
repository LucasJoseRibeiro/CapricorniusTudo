package com.capricornius.aplicativo.capricornius;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ExportarDados extends AppCompatActivity {

    private final int WRITE_EXTERNAL_STORAGE_PERMISSION = 1;

    String idUsuario;
    public BancoDados bd;
    final List<String> listaDados = new ArrayList<String>();
    private static final String[] FICHAS = new String[] { "PesagemAnimal", "EscoreCorporal", "PartoNascimento", "Desmama", "OcorrenciaDiversa",
            "SaidaAnimal", "PesagemLeite"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exportar_dados);

        bd = new BancoDados(this);
        Intent it = getIntent();

        idUsuario = it.getStringExtra("idUsuario");

        ActionBarUtil.configureActionBar(this, (float) 1.0);

        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(this,android.R.layout.select_dialog_item, FICHAS);
        AutoCompleteTextView fichas = findViewById(R.id.EDficha);
        fichas.setAdapter(adaptador);
    }

    @Override
    protected void onStart() {
        super.onStart();
        requestWritePermission(); //permissao para android 6.0 ou mais
    }

    public void ExportarDados(View view) {
        AutoCompleteTextView ficha = findViewById(R.id.EDficha);
        EditText data = findViewById(R.id.EDdata);

        String coluna1 = null, coluna2 = null, coluna3 = null, coluna4 = null, coluna5 = null, coluna6 = null;
        int quantCamposConsulta = 0;

        Cursor cursorConsulta = null;
        if(ficha.getText().toString().equals("SaidaAnimal")){
            coluna1 = "SARegistroAnimal";
            coluna2 = "SAData";
            coluna3 = "SAMotivo";
            coluna4 = "SACausa";
            coluna5 = "SAOcorrencia";
            quantCamposConsulta = 5;
        }
        else if(ficha.getText().toString().equals("PesagemAnimal")){
            coluna1 = "PARegistroAnimal";
            coluna2 = "PADataPesagem";
            coluna3 = "PAPeso";
            quantCamposConsulta = 3;
        }
        else if(ficha.getText().toString().equals("OcorrenciaDiversa")){
            coluna1 = "ODRegistroAnimal";
            coluna2 = "ODData";
            coluna3 = "ODOcorrencia";
            quantCamposConsulta = 3;
        }
        else if(ficha.getText().toString().equals("Desmama")){
            coluna1 = "DERegistroAnimal";
            coluna2 = "DEData";
            coluna3 = "DEPesoDesmama";
            quantCamposConsulta = 3;
        }
        else if(ficha.getText().toString().equals("PesagemLeite")){
            coluna1 = "PLRegistroAnimal";
            coluna2 = "PLData";
            coluna3 = "PLProducao1";
            coluna4 = "PLProducao2";
            coluna5 = "PLProducao3";
            coluna6 = "PLOcorrencia";
            quantCamposConsulta = 6;
        }

        String where = "idUsuario = '" + idUsuario + "' AND " + coluna2 + " = '" + data.getText().toString() + "'";
        boolean dataValida = false;

        if(quantCamposConsulta == 3) {
            cursorConsulta = bd.buscar(ficha.getText().toString(), new String[]{coluna1, coluna2, coluna3}, where, coluna2);
            while (cursorConsulta.moveToNext()) {
                int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                int idColuna3 = cursorConsulta.getColumnIndex(coluna3);

                listaDados.add(String.valueOf(cursorConsulta.getInt(idColuna1)));
                listaDados.add(cursorConsulta.getString(idColuna2));
                listaDados.add(cursorConsulta.getString(idColuna3));
                listaDados.add(",");
                dataValida = true;
            }
        }
        else if(quantCamposConsulta == 5) {
            cursorConsulta = bd.buscar(ficha.getText().toString(), new String[]{coluna1, coluna2, coluna3, coluna4, coluna5}, where, coluna2);
            while (cursorConsulta.moveToNext()) {
                int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                int idColuna3 = cursorConsulta.getColumnIndex(coluna3);
                int idColuna4 = cursorConsulta.getColumnIndex(coluna4);
                int idColuna5 = cursorConsulta.getColumnIndex(coluna5);

                listaDados.add(String.valueOf(cursorConsulta.getInt(idColuna1)));
                listaDados.add(cursorConsulta.getString(idColuna2));
                listaDados.add(cursorConsulta.getString(idColuna3));
                listaDados.add(cursorConsulta.getString(idColuna4));
                listaDados.add(cursorConsulta.getString(idColuna5));
                listaDados.add(",");
                dataValida = true;
            }
        }
        else if(quantCamposConsulta == 6) {
            listaDados.add("Cabra");
            listaDados.add("Manhã");
            listaDados.add("Tarde");
            listaDados.add("Noite");
            listaDados.add("Data");
            listaDados.add("Ocorrencia");
            listaDados.add(",");
            cursorConsulta = bd.buscar(ficha.getText().toString(), new String[]{coluna1, coluna2, coluna3, coluna4, coluna5, coluna6}, where, coluna2);
            while (cursorConsulta.moveToNext()) {
                int idColuna1 = cursorConsulta.getColumnIndex(coluna1);
                int idColuna2 = cursorConsulta.getColumnIndex(coluna2);
                int idColuna3 = cursorConsulta.getColumnIndex(coluna3);
                int idColuna4 = cursorConsulta.getColumnIndex(coluna4);
                int idColuna5 = cursorConsulta.getColumnIndex(coluna5);
                int idColuna6 = cursorConsulta.getColumnIndex(coluna6);

                listaDados.add(String.valueOf(cursorConsulta.getInt(idColuna1)));
                listaDados.add(cursorConsulta.getString(idColuna3));
                listaDados.add(cursorConsulta.getString(idColuna4));
                listaDados.add(cursorConsulta.getString(idColuna5));
                listaDados.add(cursorConsulta.getString(idColuna2)); // nesse caso a data será exportada depois das pesagens
                listaDados.add(cursorConsulta.getString(idColuna6));// seguindo o mesmo padrao do sistema
                listaDados.add(",");
                dataValida = true;
            }
        }

        //formatar a data do arquivo
        if((quantCamposConsulta == 5 || quantCamposConsulta == 3 || quantCamposConsulta == 6) && dataValida) { //apenas fichas corretas
            String novaData = "";
            for (int i = 0; i < data.getText().toString().length(); i++) {
                if (data.getText().toString().charAt(i) == '/') {
                    novaData = novaData + '-';
                } else {
                    novaData = novaData + data.getText().toString().charAt(i);
                }
            }

            String str_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
            File file;
            // diretorio que o arquivo sera salvo e nome do arquivo
            file = new File(str_path, ficha.getText().toString() + novaData + ".xls");
            // nome da planilha; plan1
            String sheetName = "Planilha1";//name of sheet

            //definição da planilha
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sheet = wb.createSheet(sheetName);

            HSSFRow row = null;
            int linha = 0;
            int coluna = 0;
            for (String s : listaDados) {
                if (s.equals(",")) {
                    linha++;
                    coluna = 0;
                } else {
                    if (coluna == 0) {
                        row = sheet.createRow(linha);
                    }
                    HSSFCell cell = row.createCell(coluna);
                    cell.setCellValue(s);
                    coluna++;
                }
            }
            try {
                FileOutputStream fileOut = new FileOutputStream(file);
                //write this workbook to an Outputstream.
                wb.write(fileOut);
                fileOut.flush();
                fileOut.close();
                Toast.makeText(this, "Arquivo salvo em Downloads", Toast.LENGTH_SHORT).show();

                ///////////////////////
                Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                long milliseconds = 1000;
                vibrator.vibrate(milliseconds);
                openFolder();
                bd.fechar();
                finish();
                ///////////////////////

            } catch (Exception e) {
                Toast.makeText(this, "Falha na exportação", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "Nome da ficha ou data inválido(s)", Toast.LENGTH_SHORT).show();
        }
    }

    public void requestWritePermission(){
        // verifica a necessidade de pedir a permissão
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
        // verifica se precisa explicar para o usuário a necessidade da permissão
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
        //explica para o usuário a necessidade da permissão caso ele já tenha negado pelo menos uma vez
                Toast.makeText(this,"Permita o uso de escrita!",Toast.LENGTH_LONG).show();
        //pede permissão de escrita
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        WRITE_EXTERNAL_STORAGE_PERMISSION);
                Log.i("Permission","Devo dar explicação");
            } else {
        // Pede a permissão direto a primeira vez que o usuário tentar usar o recurso.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        WRITE_EXTERNAL_STORAGE_PERMISSION);
                Log.i("Permission","Pede a permissão");
        // WRITE_EXTERNAL_STORAGE_PERMISSION é uma constante declarada para ser
        // usada no callback da resposta da permissão
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case WRITE_EXTERNAL_STORAGE_PERMISSION: {
            // Se a requisição é cancelada, um array vazio é retornado
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // permissão foi concedida. Esse ponto deve conter a ação a ser feita neste momento
                    Log.i("Permission","Deu a permissão");
                } else {
            // permissão não foi concedida pelo usuário. Desabilitar recursos que dependem dela
                    finish();
                    Log.i("Permission","Não permitiu");
                }
                return;
            }
        }
    }

    public void openFolder()
    {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath()
                + "/Downloads/");
        Log.i("teste", uri.toString());
        intent.setDataAndType(uri, "*/*");
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
