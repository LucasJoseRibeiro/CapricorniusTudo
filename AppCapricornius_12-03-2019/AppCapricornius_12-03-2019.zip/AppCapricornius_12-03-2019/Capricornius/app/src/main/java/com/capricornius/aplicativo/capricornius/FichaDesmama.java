package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaDesmama extends AppCompatActivity {

    public BancoDados bd;
    String idUsuario, registroCD, dataCD, pesoCD;
    EditText DEregistro, DEdata, DEpeso;
    int controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_desmama);

        bd = new BancoDados(this);

        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");
        controle = it.getIntExtra("controle",0);
        registroCD = it.getStringExtra("registro");
        dataCD = it.getStringExtra("data");
        pesoCD = it.getStringExtra("peso");

        ActionBarUtil.configureActionBar(this, (float) 1.0);
    }

    @Override
    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date DEdataatual = new Date();

        DEregistro = findViewById(R.id.DEedtRegistro);
        DEdata = findViewById(R.id.DEedtData);
        DEpeso = findViewById(R.id.DEedtPeso);
        DEdata.setText(simpleDateFormat.format(DEdataatual).toString());

        if(controle == 1){
            DEregistro.setText(registroCD);
            DEdata.setText(dataCD);
            DEpeso.setText(pesoCD);
        }
    }

    public void DEsalvarVoltar(View view) {
        if(controle == 1){
            int registroInt = Integer.parseInt(registroCD);
            String whereCD = "idUsuario = '" + idUsuario + "' AND DERegistroAnimal = '" + registroInt + "' AND DEData = '" + dataCD +"'";
            bd.deletar("Desmama", whereCD);
        }

        if(DEregistro.getText().length() > 0) {
            boolean temRegistroDesmama = false;
            String where = "DERegistroAnimal = '" + DEregistro.getText().toString() + "' AND DEData = '" +
                    DEdata.getText().toString() + "'"; // verificar o criatorio
            Cursor consultaDesmamaAnimais = bd.buscar("Desmama", new String[]{"DERegistroAnimal"}, where, "");

            if (consultaDesmamaAnimais != null && consultaDesmamaAnimais.getCount() > 0)
                temRegistroDesmama = true;

            if (temRegistroDesmama) {
                Toast.makeText(this, "Animal já consta nessa data", Toast.LENGTH_SHORT).show();
            }
            else {
                ContentValues infoCadastro = new ContentValues();
                infoCadastro.put("idUsuario", idUsuario);
                infoCadastro.put("DERegistroAnimal", DEregistro.getText().toString());
                infoCadastro.put("DEData", DEdata.getText().toString());
                infoCadastro.put("DEPesoDesmama", DEpeso.getText().toString());
                bd.inserir("Desmama", infoCadastro);
                //bd.fechar();
                finish();
                if(controle == 1)
                    Toast.makeText(this, "Cadastro atualizado", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else{
            Toast.makeText(this, "Informe o registro do animal", Toast.LENGTH_SHORT).show();
        }
    }

    public void DEsalvarContinuar(View view) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
