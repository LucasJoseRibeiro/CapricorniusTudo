package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class TelaCadastro extends AppCompatActivity {

    public BancoDados bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        bd = new BancoDados(this);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent it = new Intent(this, TelaLogin.class);
        startActivity(it);
    }

    public void confirmarCadastro(View view) {
        EditText usuario = findViewById(R.id.TCedtUsuario);
        EditText senha = findViewById(R.id.TCedtSenha);
        EditText criatorio = findViewById(R.id.TCedtCriatorio);
        boolean temCadastrado = false;
        String where = "Nome = '"+usuario.getText().toString()+"'";
        Cursor consultaCadastro = bd.buscar("Usuario", new String[]{"Nome"}, where, "");

        if(consultaCadastro != null && consultaCadastro.getCount() > 0)
            temCadastrado = true;

        if(!temCadastrado && usuario.getText().length() > 0 && senha.getText().length() > 0 && criatorio.getText().length() > 0){
            ContentValues infoCadastro = new ContentValues();
            infoCadastro.put("Nome", usuario.getText().toString());
            infoCadastro.put("Senha", senha.getText().toString());
            infoCadastro.put("Criatorio", criatorio.getText().toString());
            bd.inserir("Usuario", infoCadastro);

            Intent it = new Intent(this, MenuPrincipal.class);
            it.putExtra("usuario", usuario.getText().toString());
            it.putExtra("criatorio", criatorio.getText().toString());
            bd.fechar();
            startActivity(it);
            finish();
            Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Tente outro usuário", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
