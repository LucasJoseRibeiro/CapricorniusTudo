package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaSaidaAnimais extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    String[] SAmotivos = new String[] { "morte", "abate", "venda", "doação", "empréstimo", "tratamento", "furto","descarte",
            "outros", "sem informação" };
    String[] SAcausas = new String[]{"produção de leite", "idade", "fertilidade", "sanidade", "acidente", "furto", "descarte",
            "outros", "sem informação" };
    String idUsuario, SAmotivoSelec, SAcausaSelec, registroCD, dataCD, motivoCD, causaCD, descricaoCD;
    Spinner SAcomboMotivos, SAcomboCausas;
    ArrayAdapter<String> adaptadorMotivos, adaptadorCausas;
    int controle;
    EditText SAregistro, SAdata, SAdescricao;
    public BancoDados bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_saida_animais);
        bd = new BancoDados(this);

        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");
        controle = it.getIntExtra("controle", 0);
        registroCD = it.getStringExtra("registro");
        dataCD = it.getStringExtra("data");
        motivoCD = it.getStringExtra("motivo");
        causaCD = it.getStringExtra("causa");
        descricaoCD = it.getStringExtra("ocorrencia");

        ActionBarUtil.configureActionBar(this, (float) 1.0);

        SAcomboMotivos = findViewById(R.id.SAboxMotivo);
        SAcomboCausas = findViewById(R.id.SAboxCausa);
        SAcomboMotivos.setOnItemSelectedListener(this);
        SAcomboCausas.setOnItemSelectedListener(this);

        adaptadorMotivos = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, SAmotivos);
        adaptadorCausas = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, SAcausas);

        adaptadorMotivos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adaptadorCausas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        SAcomboMotivos.setAdapter(adaptadorMotivos);
        SAcomboCausas.setAdapter(adaptadorCausas);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int SAposMotivo = SAcomboMotivos.getSelectedItemPosition();
        SAmotivoSelec = adaptadorMotivos.getItem(SAposMotivo);

        int SAposCausa = SAcomboCausas.getSelectedItemPosition();
        SAcausaSelec = adaptadorCausas.getItem(SAposCausa);

        Toast.makeText(this, "Selecionados: " + SAmotivoSelec + " , " + SAcausaSelec, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date SAdataatual = new Date();

        SAregistro = findViewById(R.id.SAedtRegistro);
        SAdata = findViewById(R.id.SAedtData);
        SAdescricao = findViewById(R.id.SAedtDescricao);
        SAdata.setText(simpleDateFormat.format(SAdataatual).toString());

        if(controle == 1){
            SAregistro.setText(registroCD);
            SAdata.setText(dataCD);
            SAmotivoSelec = motivoCD;// nao muda na tela o spinner
            SAcausaSelec = causaCD;// nao muda na tela o spinner
            SAdescricao.setText(descricaoCD);
        }
    }

    public void SAsalvarContinuar(View view) {

    }

    public void SAsalvarVoltar(View view) {
        if(controle == 1){
            int registroInt = Integer.parseInt(registroCD);
            String whereCD = "idUsuario = '" + idUsuario + "' AND SARegistroAnimal = '" + registroInt + "'";
            bd.deletar("SaidaAnimal", whereCD);
        }

        if(SAregistro.getText().length() > 0) {
            boolean temRegistroSaida = false;
            String where = "SARegistroAnimal = '"+SAregistro.getText().toString()+"'"; //verificar o criatorio
            Cursor consultaSaidaAnimais = bd.buscar("SaidaAnimal", new String[]{"SARegistroAnimal"}, where, "");

            if (consultaSaidaAnimais != null && consultaSaidaAnimais.getCount() > 0)
                temRegistroSaida = true;

            if (temRegistroSaida) {
                Toast.makeText(this, "Já consta a saída do animal", Toast.LENGTH_SHORT).show();
            }
            else {
                ContentValues infoCadastro = new ContentValues();
                infoCadastro.put("idUsuario", idUsuario);
                infoCadastro.put("SARegistroAnimal", SAregistro.getText().toString());
                infoCadastro.put("SAData", SAdata.getText().toString());
                infoCadastro.put("SAMotivo", SAmotivoSelec);
                infoCadastro.put("SACausa", SAcausaSelec);
                infoCadastro.put("SAOcorrencia", SAdescricao.getText().toString());
                bd.inserir("SaidaAnimal", infoCadastro);
                //bd.fechar();
                finish();
                if(controle == 1)
                    Toast.makeText(this, "Cadastro atualizado", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else{
            Toast.makeText(this, "Informe o registro do animal", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
