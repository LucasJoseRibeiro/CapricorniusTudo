package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaPesagemAnimal extends AppCompatActivity {

    public BancoDados bd;
    String idUsuario, registroCD, dataCD, pesoCD;
    EditText PAregistro, PAdata, PApeso;
    int controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_pesagem_animal);

        bd = new BancoDados(this);

        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");
        controle = it.getIntExtra("controle",0);
        registroCD = it.getStringExtra("registro");
        dataCD = it.getStringExtra("data");
        pesoCD = it.getStringExtra("peso");

        ActionBarUtil.configureActionBar(this, (float) 1.0);
    }

    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date PAdataatual = new Date();

        PAregistro = findViewById(R.id.PAedtRegistro);
        PAdata = findViewById(R.id.PAedtDataPesagem);
        PApeso = findViewById(R.id.PAedtPeso);
        PAdata.setText(simpleDateFormat.format(PAdataatual).toString());

        if(controle == 1){
            PAregistro.setText(registroCD);
            PAdata.setText(dataCD);
            PApeso.setText(pesoCD);
        }
    }

    public void PAsalvarVoltar(View view) {
        if(controle == 1){
            int registroInt = Integer.parseInt(registroCD);
            String whereCD = "idUsuario = '" + idUsuario + "' AND PARegistroAnimal = '" + registroInt + "' AND PADataPesagem = '" + dataCD +"'";
            bd.deletar("PesagemAnimal", whereCD);
        }

        if(PAregistro.getText().length() > 0) {
            boolean temRegistroPesagem = false;
            String where = "PARegistroAnimal = '" + PAregistro.getText().toString() + "' AND PADataPesagem = '" +
                    PAdata.getText().toString() + "'"; // verificar o criatorio
            Cursor consultaPesagemAnimais = bd.buscar("PesagemAnimal", new String[]{"PARegistroAnimal"}, where, "");

            if (consultaPesagemAnimais != null && consultaPesagemAnimais.getCount() > 0)
                temRegistroPesagem = true;

            if (temRegistroPesagem) {
                Toast.makeText(this, "Animal já pesado nessa data", Toast.LENGTH_SHORT).show();
            }
            else {
                ContentValues infoCadastro = new ContentValues();
                infoCadastro.put("idUsuario", idUsuario);
                infoCadastro.put("PARegistroAnimal", PAregistro.getText().toString());
                infoCadastro.put("PADataPesagem", PAdata.getText().toString());
                infoCadastro.put("PAPeso", PApeso.getText().toString());
                bd.inserir("PesagemAnimal", infoCadastro);
                //bd.fechar();
                finish();
                if(controle == 1)
                    Toast.makeText(this, "Cadastro atualizado", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else{
            Toast.makeText(this, "Informe o registro do animal", Toast.LENGTH_SHORT).show();
        }
    }

    public void PAsalvarContinuar(View view) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
