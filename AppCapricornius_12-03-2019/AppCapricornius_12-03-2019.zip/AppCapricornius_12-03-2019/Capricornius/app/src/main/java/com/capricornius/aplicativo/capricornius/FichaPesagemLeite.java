package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaPesagemLeite extends AppCompatActivity {

    public BancoDados bd;
    String idUsuario, registroCD, dataCD, producao1CD, producao2CD, producao3CD, ocorrenciaCD;
    EditText PLregistro, PLdata, PLproducao1, PLproducao2, PLproducao3, PLocorrencia;
    int controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_pesagem_leite);

        bd = new BancoDados(this);

        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");
        controle = it.getIntExtra("controle",0);
        registroCD = it.getStringExtra("registro");
        dataCD = it.getStringExtra("data");
        producao1CD = it.getStringExtra("producao1");
        producao2CD = it.getStringExtra("producao2");
        producao3CD = it.getStringExtra("producao3");
        ocorrenciaCD = it.getStringExtra("ocorrencia");

        ActionBarUtil.configureActionBar(this, (float) 1.0);
    }

    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date PLdataatual = new Date();

        PLregistro = findViewById(R.id.PLedtRegistro);
        PLdata = findViewById(R.id.PLedtData);
        PLproducao1 = findViewById(R.id.PLedtProducao1);
        PLproducao2 = findViewById(R.id.PLedtProducao2);
        PLproducao3 = findViewById(R.id.PLedtProducao3);
        PLocorrencia = findViewById(R.id.PLedtOcorrencia);
        PLdata.setText(simpleDateFormat.format(PLdataatual).toString());

        if(controle == 1){
            PLregistro.setText(registroCD);
            PLdata.setText(dataCD);
            PLproducao1.setText(producao1CD);
            PLproducao2.setText(producao2CD);
            PLproducao3.setText(producao3CD);
            PLocorrencia.setText(ocorrenciaCD);
        }
    }

    public void PLsalvarVoltar(View view) {
        if(controle == 1){
            int registroInt = Integer.parseInt(registroCD);
            String whereCD = "idUsuario = '" + idUsuario + "' AND PLRegistroAnimal = '" + registroInt + "' AND PLData = '" + dataCD +"'";
            bd.deletar("PesagemLeite", whereCD);
        }

        if(PLregistro.getText().length() > 0) {
            boolean temRegistroPesagemLeite = false;
            String where = "PLRegistroAnimal = '" + PLregistro.getText().toString() + "' AND PLData = '" +
                    PLdata.getText().toString() + "'"; // verificar o criatorio
            Cursor consultaPesagemLeite = bd.buscar("PesagemLeite", new String[]{"PLRegistroAnimal"}, where, "");

            if (consultaPesagemLeite != null && consultaPesagemLeite.getCount() > 0)
                temRegistroPesagemLeite = true;

            if (temRegistroPesagemLeite) {
                Toast.makeText(this, "Animal já consta nessa data", Toast.LENGTH_SHORT).show();
            }
            else {
                ContentValues infoCadastro = new ContentValues();
                infoCadastro.put("idUsuario", idUsuario);
                infoCadastro.put("PLRegistroAnimal", PLregistro.getText().toString());
                infoCadastro.put("PLData", PLdata.getText().toString());
                infoCadastro.put("PLProducao1", PLproducao1.getText().toString());
                infoCadastro.put("PLProducao2", PLproducao2.getText().toString());
                infoCadastro.put("PLProducao3", PLproducao3.getText().toString());
                infoCadastro.put("PLOcorrencia", PLocorrencia.getText().toString());
                bd.inserir("PesagemLeite", infoCadastro);
                //bd.fechar();
                finish();
                if(controle == 1)
                    Toast.makeText(this, "Cadastro atualizado", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public void PLsalvarContinuar(View view) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
