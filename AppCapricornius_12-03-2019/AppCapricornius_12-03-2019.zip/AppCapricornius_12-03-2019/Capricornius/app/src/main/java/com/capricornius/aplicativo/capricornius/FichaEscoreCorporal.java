package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FichaEscoreCorporal extends AppCompatActivity {

    public BancoDados bd;
    String idUsuario, registroCD, dataCD, avaliacao1CD, avaliacao2CD, avaliacao3CD;
    EditText ECregistro, ECdata, ECavaliador1, ECavaliador2, ECavaliador3;
    int controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha_escore_corporal);

        bd = new BancoDados(this);

        Intent it = getIntent();
        idUsuario = it.getStringExtra("idUsuario");
        controle = it.getIntExtra("controle",0);
        registroCD = it.getStringExtra("registro");
        dataCD = it.getStringExtra("data");
        avaliacao1CD = it.getStringExtra("avaliador1");
        avaliacao2CD = it.getStringExtra("avaliador2");
        avaliacao3CD = it.getStringExtra("avaliador3");

        ActionBarUtil.configureActionBar(this, (float) 1.0);
    }

    protected void onStart() {
        super.onStart();

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date ECdataatual = new Date();

        ECregistro = findViewById(R.id.ECedtRegistro);
        ECdata = findViewById(R.id.ECedtData);
        ECavaliador1 = findViewById(R.id.ECedtAvaliador1);
        ECavaliador2 = findViewById(R.id.ECedtAvaliador2);
        ECavaliador3 = findViewById(R.id.ECedtAvaliador3);
        ECdata.setText(simpleDateFormat.format(ECdataatual).toString());

        if(controle == 1){
            ECregistro.setText(registroCD);
            ECdata.setText(dataCD);
            ECavaliador1.setText(avaliacao1CD);
            ECavaliador2.setText(avaliacao2CD);
            ECavaliador3.setText(avaliacao3CD);
        }
    }

    public void ECsalvarContinuar(View view) {

    }

    public void ECsalvarVoltar(View view) {
        if(controle == 1){
            int registroInt = Integer.parseInt(registroCD);
            String whereCD = "idUsuario = '" + idUsuario + "' AND ECRegistroAnimal = '" + registroInt + "' AND ECData = '" + dataCD +"'";
            bd.deletar("EscoreCorporal", whereCD);
        }

        if(ECregistro.getText().length() > 0) {
            boolean temRegistroEscore = false;
            String where = "ECRegistroAnimal = '" + ECregistro.getText().toString() + "' AND ECData = '" +
                    ECdata.getText().toString() + "'";
            Cursor consultaEscoreAnimais = bd.buscar("EscoreCorporal", new String[]{"ECRegistroAnimal"}, where, "");

            if (consultaEscoreAnimais != null && consultaEscoreAnimais.getCount() > 0)
                temRegistroEscore = true;

            if (temRegistroEscore) {
                Toast.makeText(this, "Animal já consta nessa data", Toast.LENGTH_SHORT).show();
            }
            else {
                ContentValues infoCadastro = new ContentValues();
                infoCadastro.put("idUsuario", idUsuario);
                infoCadastro.put("ECRegistroAnimal", ECregistro.getText().toString());
                infoCadastro.put("ECData", ECdata.getText().toString());
                infoCadastro.put("ECAvaliacao1", ECavaliador1.getText().toString());
                infoCadastro.put("ECAvaliacao2", ECavaliador2.getText().toString());
                infoCadastro.put("ECAvaliacao3", ECavaliador3.getText().toString());
                bd.inserir("EscoreCorporal", infoCadastro);
                //bd.fechar();
                finish();
                if(controle == 1)
                    Toast.makeText(this, "Cadastro atualizado", Toast.LENGTH_SHORT).show();
                else{
                    Toast.makeText(this, "Cadastro realizado", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else{
            Toast.makeText(this, "Informe o registro do animal", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                //bd.fechar();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
