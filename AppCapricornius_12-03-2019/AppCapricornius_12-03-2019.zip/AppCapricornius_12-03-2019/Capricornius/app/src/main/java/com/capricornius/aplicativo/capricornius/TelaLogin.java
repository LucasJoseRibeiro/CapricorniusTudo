package com.capricornius.aplicativo.capricornius;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class TelaLogin extends AppCompatActivity {

    public BancoDados bd;
    Cursor consultaUsuarioUltimo;
    boolean existeUltimoUsuario = false;
    String ultimoNome, ultimaSenha;
    EditText usuario, senha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);
        bd = new BancoDados(this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        consultaUsuarioUltimo = bd.buscar("UltimoUsuario", new String[]{"UltimoNome", "UltimaSenha"}, "", "");
        if(consultaUsuarioUltimo != null && consultaUsuarioUltimo.getCount() > 0)
            existeUltimoUsuario = true;

        if(existeUltimoUsuario){
            while (consultaUsuarioUltimo.moveToNext()){
                int idUltimoNome = consultaUsuarioUltimo.getColumnIndex("UltimoNome");
                int idUltimaSenha = consultaUsuarioUltimo.getColumnIndex("UltimaSenha");
                ultimoNome = consultaUsuarioUltimo.getString(idUltimoNome);
                ultimaSenha = consultaUsuarioUltimo.getString(idUltimaSenha);
            }
            usuario = findViewById(R.id.TLedtUsuario);
            senha = findViewById(R.id.TLedtSenha);
            usuario.setText(ultimoNome);
            senha.setText(ultimaSenha);
        }
    }

    // criar uma tabela de ultimo usuario e armazenar sempre o login for feito, sempre apagar o usuario antes de inserir - fazer domingo
    public void Entrar(View view) {
        usuario = findViewById(R.id.TLedtUsuario);
        senha = findViewById(R.id.TLedtSenha);
        boolean validaUsuario = false;
        String where = "Nome = '"+usuario.getText().toString()+"' AND Senha = '"+senha.getText().toString()+"'";
        Cursor consultaUsuario = bd.buscar("Usuario", new String[]{"Nome", "Senha", "Criatorio"}, where, "");

        if (consultaUsuario != null && consultaUsuario.getCount() > 0)
            validaUsuario = true;

        if(validaUsuario) {
            String criatorio = "";
            while (consultaUsuario.moveToNext()){
                int idCriatorio = consultaUsuario.getColumnIndex("Criatorio");
                criatorio = consultaUsuario.getString(idCriatorio);
            }
            Intent it = new Intent(this, MenuPrincipal.class);
            it.putExtra("usuario", usuario.getText().toString());
            it.putExtra("criatorio", criatorio);

            if(existeUltimoUsuario){
                bd.deletar("UltimoUsuario", "");
            }
            ContentValues infoUltimoUsuario = new ContentValues();
            infoUltimoUsuario.put("UltimoNome", usuario.getText().toString());
            infoUltimoUsuario.put("UltimaSenha", senha.getText().toString());
            bd.inserir("UltimoUsuario", infoUltimoUsuario);

            bd.fechar();
            startActivity(it);
            finish();
        }
        else{
            Toast.makeText(this, "Usuário e/ou senha inválidos", Toast.LENGTH_SHORT).show();
        }
    }

    public void Cadastrar(View view) {
        Intent it = new Intent(this, TelaCadastro.class);
        bd.fechar();
        startActivity(it);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bd.fechar();
    }
}
