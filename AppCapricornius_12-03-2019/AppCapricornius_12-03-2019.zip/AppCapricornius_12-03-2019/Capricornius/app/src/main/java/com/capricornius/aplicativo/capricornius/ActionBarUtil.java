package com.capricornius.aplicativo.capricornius;

import android.support.v7.app.AppCompatActivity;

public class ActionBarUtil {

    public static void configureActionBar(AppCompatActivity ctx, float elevation){
        ctx.getSupportActionBar().setDisplayHomeAsUpEnabled(true); // botão voltar
        ctx.getSupportActionBar().setElevation(elevation);
    }
    public static void configureActionBar(AppCompatActivity ctx, int iconHome){
        ctx.getSupportActionBar().setHomeAsUpIndicator(iconHome); //Ex: botão close
        ctx.getSupportActionBar().setDisplayHomeAsUpEnabled(true); // ativa botão. Ex: close
    }

}
